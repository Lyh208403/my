import os
import sqlite3
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("DATA_DIR", APP_DIR)
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "mynav.db")
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-before-deploying")
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "ChangeMe123!")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp", "pdf", "txt", "zip"}
MAX_UPLOAD_BYTES = 8 * 1024 * 1024

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, url TEXT NOT NULL, category TEXT NOT NULL DEFAULT '常用工具',
            description TEXT NOT NULL DEFAULT '', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS announcements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, body TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, price TEXT NOT NULL DEFAULT '',
            url TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT ''
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
            disabled INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY, value TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS visits (
            id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT,
            visited_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('site_title','MyNav 独立导航')")
        conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('site_subtitle','把常用网站与工具整理在一个地方')")
        count = conn.execute("SELECT COUNT(*) AS n FROM links").fetchone()["n"]
        if count == 0:
            starter = [
                ("Google", "https://www.google.com", "搜索", "网页搜索"),
                ("GitHub", "https://github.com", "开发", "代码托管与项目管理"),
                ("ChatGPT", "https://chatgpt.com", "AI工具", "AI 助手"),
                ("MDN Web Docs", "https://developer.mozilla.org", "开发", "Web 开发文档"),
            ]
            conn.executemany("INSERT INTO links(title,url,category,description) VALUES(?,?,?,?)", starter)

def setting(key, default=""):
    with db() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("is_admin"):
            return redirect(url_for("admin_login", next=request.path))
        return fn(*args, **kwargs)
    return wrapper

@app.before_request
def record_visit():
    if request.endpoint and not request.endpoint.startswith("static"):
        try:
            with db() as conn:
                conn.execute("INSERT INTO visits(path) VALUES(?)", (request.path[:250],))
        except sqlite3.Error:
            pass

@app.route("/")
def index():
    with db() as conn:
        links = conn.execute("SELECT * FROM links ORDER BY category, title").fetchall()
        announcements = conn.execute("SELECT * FROM announcements ORDER BY id DESC LIMIT 5").fetchall()
    categories = {}
    for link in links:
        categories.setdefault(link["category"], []).append(link)
    return render_template("index.html", categories=categories, announcements=announcements,
                           site_title=setting("site_title", "MyNav 独立导航"),
                           site_subtitle=setting("site_subtitle", "把常用网站与工具整理在一个地方"))

@app.route("/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username == ADMIN_USERNAME and check_password_hash(generate_password_hash(ADMIN_PASSWORD), password):
            session.clear()
            session["is_admin"] = True
            return redirect(request.args.get("next") or url_for("admin"))
        flash("账号或密码不正确。")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/admin")
@admin_required
def admin():
    with db() as conn:
        links = conn.execute("SELECT * FROM links ORDER BY id DESC").fetchall()
        announcements = conn.execute("SELECT * FROM announcements ORDER BY id DESC").fetchall()
        products = conn.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
        users = conn.execute("SELECT id,username,disabled,created_at FROM users ORDER BY id DESC").fetchall()
        visit_count = conn.execute("SELECT COUNT(*) AS n FROM visits").fetchone()["n"]
        recent_visits = conn.execute("SELECT path,visited_at FROM visits ORDER BY id DESC LIMIT 20").fetchall()
        files = sorted(os.listdir(UPLOAD_DIR)) if os.path.isdir(UPLOAD_DIR) else []
    return render_template("admin.html", links=links, announcements=announcements,
                           products=products, users=users, visit_count=visit_count,
                           recent_visits=recent_visits, files=files,
                           site_title=setting("site_title"), site_subtitle=setting("site_subtitle"))

@app.route("/admin/link", methods=["POST"])
@admin_required
def add_link():
    title = request.form.get("title", "").strip()
    url = request.form.get("url", "").strip()
    category = request.form.get("category", "常用工具").strip() or "常用工具"
    description = request.form.get("description", "").strip()
    if title and url.startswith(("https://", "http://")):
        with db() as conn:
            conn.execute("INSERT INTO links(title,url,category,description) VALUES(?,?,?,?)",
                         (title[:100], url[:500], category[:60], description[:250]))
        flash("导航链接已添加。")
    else:
        flash("请填写名称，并使用 http:// 或 https:// 开头的网址。")
    return redirect(url_for("admin"))

@app.route("/admin/link/<int:item_id>/delete", methods=["POST"])
@admin_required
def delete_link(item_id):
    with db() as conn:
        conn.execute("DELETE FROM links WHERE id=?", (item_id,))
    return redirect(url_for("admin"))

@app.route("/admin/announcement", methods=["POST"])
@admin_required
def add_announcement():
    title = request.form.get("title", "").strip()
    body = request.form.get("body", "").strip()
    if title and body:
        with db() as conn:
            conn.execute("INSERT INTO announcements(title,body) VALUES(?,?)", (title[:120], body[:1000]))
        flash("公告已发布。")
    return redirect(url_for("admin"))

@app.route("/admin/announcement/<int:item_id>/delete", methods=["POST"])
@admin_required
def delete_announcement(item_id):
    with db() as conn:
        conn.execute("DELETE FROM announcements WHERE id=?", (item_id,))
    return redirect(url_for("admin"))

@app.route("/admin/settings", methods=["POST"])
@admin_required
def save_settings():
    title = request.form.get("site_title", "").strip()[:100] or "MyNav 独立导航"
    subtitle = request.form.get("site_subtitle", "").strip()[:250]
    with db() as conn:
        conn.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('site_title',?)", (title,))
        conn.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('site_subtitle',?)", (subtitle,))
    flash("首页设置已保存。")
    return redirect(url_for("admin"))

@app.route("/admin/product", methods=["POST"])
@admin_required
def add_product():
    name = request.form.get("name", "").strip()
    price = request.form.get("price", "").strip()
    url = request.form.get("url", "").strip()
    description = request.form.get("description", "").strip()
    if name:
        with db() as conn:
            conn.execute("INSERT INTO products(name,price,url,description) VALUES(?,?,?,?)",
                         (name[:120], price[:80], url[:500], description[:250]))
        flash("商品已添加。")
    return redirect(url_for("admin"))

@app.route("/admin/product/<int:item_id>/delete", methods=["POST"])
@admin_required
def delete_product(item_id):
    with db() as conn:
        conn.execute("DELETE FROM products WHERE id=?", (item_id,))
    return redirect(url_for("admin"))

@app.route("/admin/user", methods=["POST"])
@admin_required
def add_user():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    if len(username) >= 3 and len(password) >= 8:
        try:
            with db() as conn:
                conn.execute("INSERT INTO users(username,password_hash) VALUES(?,?)",
                             (username[:80], generate_password_hash(password)))
            flash("用户已创建。")
        except sqlite3.IntegrityError:
            flash("这个用户名已经存在。")
    else:
        flash("用户名至少 3 个字符，密码至少 8 个字符。")
    return redirect(url_for("admin"))

@app.route("/admin/user/<int:user_id>/toggle", methods=["POST"])
@admin_required
def toggle_user(user_id):
    with db() as conn:
        conn.execute("UPDATE users SET disabled=CASE WHEN disabled=0 THEN 1 ELSE 0 END WHERE id=?", (user_id,))
    return redirect(url_for("admin"))

@app.route("/admin/upload", methods=["POST"])
@admin_required
def upload_file():
    file = request.files.get("file")
    if not file or not file.filename:
        flash("请先选择文件。")
        return redirect(url_for("admin"))
    filename = secure_filename(file.filename)
    if "." not in filename or filename.rsplit(".", 1)[1].lower() not in ALLOWED_EXTENSIONS:
        flash("文件类型不允许。")
        return redirect(url_for("admin"))
    file.stream.seek(0, os.SEEK_END)
    size = file.stream.tell()
    file.stream.seek(0)
    if size > MAX_UPLOAD_BYTES:
        flash("文件最大 8 MB。")
        return redirect(url_for("admin"))
    file.save(os.path.join(UPLOAD_DIR, filename))
    flash("文件上传成功。")
    return redirect(url_for("admin"))

@app.route("/admin/upload/<path:filename>/delete", methods=["POST"])
@admin_required
def delete_file(filename):
    safe = secure_filename(filename)
    path = os.path.join(UPLOAD_DIR, safe)
    if os.path.isfile(path):
        os.remove(path)
    return redirect(url_for("admin"))

@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    safe = secure_filename(filename)
    path = os.path.join(UPLOAD_DIR, safe)
    if not os.path.isfile(path):
        abort(404)
    from flask import send_from_directory
    return send_from_directory(UPLOAD_DIR, safe)

@app.route("/health")
def health():
    return {"status": "ok"}

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")))
